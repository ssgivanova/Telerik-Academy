﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Infestation
{
    public class PowerCatalyst : SupplementBase
    {
        public PowerCatalyst() 
            : base(3, 0, 0)
        {
        }
    }
}
